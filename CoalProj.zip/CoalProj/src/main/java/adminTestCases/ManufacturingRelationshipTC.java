package adminTestCases;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import coalAdminPages.ManufacturingRelationship;
import coalBase.BaseMethods;
import utilis.DPMR;

public class ManufacturingRelationshipTC extends BaseMethods
{
	
	@BeforeTest
	public void startt() throws Exception
	{
		startApplication("Chrome");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@id='UserName']")).sendKeys("A5G7QZZ");
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("Congruent2018!@#$");
		
		driver.findElement(By.xpath("//*[@id='divLoginForm']/form/div[7]/button")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//i[@class='fa fa-user fa-lg']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Manufacturing Relationship (MR)')]")).click();	
	}
	

	@DataProvider(name="ManufacturingRelationship")
	public static Object[][] readMR() throws Exception 
	{
		Object[][] arrayObject = DPMR.readOperationMR();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ManufacturingRelationship", priority=1)
	public void readMRTC(String data1,String data2,String data3) throws Exception
	{
	Thread.sleep(2000);
	ManufacturingRelationship manufrel = new ManufacturingRelationship(driver);
	manufrel.manufacturingRelationshipadd();
	//manufrel.productcheckbox();
	manufrel.manufacturingRelationship(data1);
	manufrel.MROperations(data2);
	manufrel.autoComponent(data3);
	}
}
