package adminTestCases;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import coalAdminPages.Routing;
import coalBase.BaseMethods;
import utilis.DPRouting;

public class RoutingTC extends BaseMethods
{
	
	@BeforeTest
	public void startt() throws Exception
	{
		startApplication("Chrome");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@id='UserName']")).sendKeys("A5G7QZZ");
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("Congruent2018!@#$");
		
		driver.findElement(By.xpath("//*[@id='divLoginForm']/form/div[7]/button")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//i[@class='fa fa-user fa-lg']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='ribbon-3']/ul/li[5]/a")).click();	
	}

	
	@DataProvider(name="Routing")
	public static Object[][] readRouting() throws Exception 
	{
		Object[][] arrayObject = DPRouting.readRouting();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Routing", priority=1)
	public void readRoutingTC(String data1,String data2) throws Exception
	{
	Thread.sleep(2000);
	Routing route = new Routing(driver);
	route.routingAddbtn();
	route.routeName(data1);
	route.routeProduct(data2);
	//route.routeStatus(data3);
	route.expandAll();
	
	
	//route.expandAll();	
	//route.isTemplate(data4);
	//route.needFocusFactory(data5);
	//route.saveButton();
	
	}
}
