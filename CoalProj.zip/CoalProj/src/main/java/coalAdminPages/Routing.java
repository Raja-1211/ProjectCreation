package coalAdminPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import coalBase.BaseMethods;

public class Routing extends BaseMethods
{
	public Routing(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void routingAddbtn() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='divRouting']/div[1]/div/a")).click();
	}
	
	public void routeName(String data1) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='Name']")).sendKeys("Sticky Coal Routing");
	}
	
	public void routeProduct(String data2) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='txtModelRouteFinishedGood']")).sendKeys("5-Mil - 895492 / PET Production");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='txtModelRouteFinishedGood_listbox']/li[2]")).click();
		
		
		
		
		
		/*if(data2.equalsIgnoreCase("Product"))
		{
		driver.findElement(By.xpath("//input[@id='rbProduct']")).click();
		driver.findElement(By.xpath("//input[@id='txtModelRouteFinishedGood']")).sendKeys("Granule MSC");
		}
		else if(data2.equalsIgnoreCase("Product Family"))
		{
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@id='rbProductFamily']")).click();
			driver.findElement(By.xpath("//input[@name='AutoProductFamily']")).sendKeys("Granule MSC");
		}*/
	}
	
	public void routeStatus(String data3) throws InterruptedException
	{
		Thread.sleep(2000);
		if(data3.equalsIgnoreCase("Active"))
		{
		Select active = new Select(driver.findElement(By.xpath("//*[@id='Status']")));
		active.selectByVisibleText("Active");
		}
		else if(data3.equalsIgnoreCase("InActive"))
		{
			Select inactive = new Select(driver.findElement(By.xpath("//*[@id='Status']")));
			inactive.selectByVisibleText("InActive");
		}
		else if(data3.equalsIgnoreCase("InProgress"))
		{
			Select inprogress = new Select(driver.findElement(By.xpath("//*[@id='Status']")));
			inprogress.selectByVisibleText("InProgress");
		}
	}
	
	public void isTemplate(String data1) throws InterruptedException
	{
		Thread.sleep(2000);
		if(data1.equalsIgnoreCase("yes"))
		{
			driver.findElement(By.xpath("//input[@id='IsTemplate']")).click();
		}else if(data1.equalsIgnoreCase("No"))
		{
		}
	}
	
	public void needFocusFactory(String data1) throws InterruptedException
	{
		Thread.sleep(2000);
		if(data1.equalsIgnoreCase("yes"))
		{
			driver.findElement(By.xpath("//input[@id='IsFocusFactoryNeeded']")).click();
		}else if(data1.equalsIgnoreCase("No"))
		{	
		}
	}
	
	public void saveButton() throws Exception
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='btnSave']")).click();
	}
	
	public void cancelbutton() throws Exception
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='btnCancel']")).click();
	}
	
	public void expandAll() throws Exception
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='NextOperationID']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='NextOperationID']/option[2]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='Check_14_14_0_1264']")).click();
		Thread.sleep(2000);
		/*driver.findElement(By.xpath("//*[@id='NextOperationID']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='NextOperationID']/option[2]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='Check_186_186_0_3979']")).click();*/
		//save
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='btnSave']")).click();
	}
	
	
	
	
	
}
