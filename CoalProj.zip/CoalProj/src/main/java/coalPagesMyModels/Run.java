package coalPagesMyModels;

import coalBase.BaseMethods;

public class Run extends BaseMethods
{

	public void validate()
	{
		
	}
	
	public void PropagateDemand()
	{
		
	}	
			
}
