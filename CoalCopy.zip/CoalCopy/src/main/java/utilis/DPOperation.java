package utilis;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DPOperation 
{
	public static int rowCount;
	public static String[][] readOperation() throws IOException
	{
		String[][] data = null;

		try{
			FileInputStream fis = new FileInputStream(new File("C:\\Users\\Raja.k\\git\\Coalrepository\\CoalCopy\\ExcelData\\DataExcelImport.xlsx"));
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheetAt(9);
			rowCount = sheet.getLastRowNum();
			int columnCount = sheet.getRow(2).getLastCellNum();
			data = new String[rowCount][columnCount];

			for (int i = 2; i<rowCount+1; i++) {
				try {
					XSSFRow row = sheet.getRow(i);
					
					for (int j = 0; j<columnCount; j++) {
						try {
							String cellValue = "";
							try {
								cellValue = row.getCell(j).getStringCellValue();
								
								System.out.println(cellValue);
							} catch (NullPointerException e) {

							}
							data[i-1][j] = cellValue;
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			fis.close();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data;

	}
}
