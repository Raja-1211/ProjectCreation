package adminTestCases;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import coalAdminPages.OperationWorkCenter;
import coalBase.BaseMethods;
import utilis.DPOperation;
import utilis.DPOperationGroup;
import utilis.DPOperationType;
import utilis.DPUnitConverison;
import utilis.DPWorkCenter;

public class OperationWorkCenterTC extends BaseMethods
{
	@BeforeTest
	public void startt() throws Exception
	{
		startApplication("Chrome");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@id='UserName']")).sendKeys("A5G7QZZ");
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("Congruent2018!@#$");
		
		driver.findElement(By.xpath("//*[@id='divLoginForm']/form/div[7]/button")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//i[@class='fa fa-user fa-lg']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Operation | Work Center')]")).click();	
	}
	
	@DataProvider(name="ReadOperation")
	public static Object[][] readOperation() throws Exception 
	{
		Object[][] arrayObject = DPOperation.readOperation();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ReadOperation", priority=1)
	public void readOperationtc(String data1,String data2,String data3,String data4,String data5,String data6) throws Exception
	{
	Thread.sleep(2000);
	OperationWorkCenter operationtest = new OperationWorkCenter(driver);
	operationtest.operationName(data1);
	operationtest.operationSName(data2);
	operationtest.operationRegion(data3);
	operationtest.operationGroupName(data4);
	operationtest.operationTypeName(data5);
	operationtest.operationDivisionName(data6);
	}
	
	@DataProvider(name="ReadOperationGroup")
	public static Object[][] readOperationGroup() throws Exception 
	{
		Object[][] arrayObject = DPOperationGroup.readOperationGroup();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ReadOperationGroup", priority=2)
	public void readOperationGrouptc(String data7) throws Exception
	{
		OperationWorkCenter opg = new OperationWorkCenter(driver);
		opg.operationGroup(data7);
	}
	
	@DataProvider(name="ReadOperationType")
	public static Object[][] readOperationType() throws Exception 
	{
		Object[][] arrayObject = DPOperationType.readOperationType();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ReadOperationType", priority=3)
	public void readOperationTypetc(String data8) throws Exception
	{
		OperationWorkCenter optype = new OperationWorkCenter(driver);
		optype.operationType(data8);
	}
	
	@DataProvider(name="ReadOperationWC")
	public static Object[][] readOperationWc() throws Exception 
	{
		Object[][] arrayObject = DPWorkCenter.readOperationWC();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ReadOperationWC", priority=4)
	public void readOperationWctc(String data9,String data10) throws Exception
	{
		OperationWorkCenter opwc = new OperationWorkCenter(driver);
		opwc.workCenterName(data9);
		opwc.workCenterSName(data10);
	}
	
	@DataProvider(name="ReadOperationUnitConc")
	public static Object[][] readOperationUnitConversion() throws Exception 
	{
		Object[][] arrayObject = DPUnitConverison.readOperationWC();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ReadOperationUnitConc", priority=5)
	public void readOperationUnitConv(String data11,String data12,String data13,String data14) throws Exception
	{
		OperationWorkCenter opuc = new OperationWorkCenter(driver);
		opuc.unitConversionlevel(data11);
		opuc.unitConversionWC(data12);
		opuc.unitConversionFunit(data13);
		opuc.unitConversionTunit(data14);
		//opuc.unitConversionCFactor(data15);
		opuc.manufacturingRelationship();
	}
	
}
