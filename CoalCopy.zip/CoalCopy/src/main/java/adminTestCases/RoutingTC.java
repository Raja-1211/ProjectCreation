package adminTestCases;

import org.testng.annotations.DataProvider;

public class RoutingTC extends BaseMethods
{

	@DataProvider(name="Routing")
	public static Object[][] readRouting() throws Exception 
	{
		Object[][] arrayObject = DPRouting.readRouting();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Routing", priority=1)
	public void readRoutingTC(String data1,String data2,String data3,String data4, String data5, String data6) throws Exception
	{
	Thread.sleep(2000);
	Routing route = new Routing(driver);
	route.routingAddbtn();
	route.routeName(data1);
	route.routeProduct(data1);
	route.routeStatus(data1);
	route.isTemplate(data1);
	route.needFocusFactory(data1);
	route.saveButton();
	route.expandAll();	
	}
}
