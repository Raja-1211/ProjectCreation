package coalPagesMyModels;

public class AllModels
{
	public void myModels()
	{
		//driver.findElement(By.xpath("/[@id=\"limenumymodels\"]/a"));
	}
	
	public void allModel()
	{
		//driver.findElement(By.xpath("//*[@id=\"grdModel\"]/div[1]/div/table/thead/tr/th[5]/a[2]"));
	}
	
	
	
	
}
