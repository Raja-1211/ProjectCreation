package coalPagesMyModels;

public class Inputs
{

	public void general()
	{
		//driver.findElement(By.xpath("//*[@id='Name']"));
		//driver.findElement(By.xpath("//div[@id='myModal']"));
		
		//Select uom = new Select(driver.findElement(By.xpath("//select[@id='UnitOfMeasurementID']")));
		//uom.selectByVisibleText("EACH");	
	}
	
	public void planningmethod(String value)
	{
		if(value.equalsIgnoreCase("Time-based"))
		{
			//driver.findElement(By.xpath("//*[@id='formEditModel']/div[2]/div[1]/div[3]/div[1]/div[2]/div/label[1]")).click();
		}
		
		else if(value.equalsIgnoreCase("Capacity-based"))
		{
			//driver.findElement(By.xpath("//*[@id='formEditModel']/div[2]/div[1]/div[3]/div[1]/div[2]/div/label[2]")).click();
		}
	}
	
	public void planningHorizon()
	{
		
	}
	
	public void products()
	{
		
	}
	
	public void customers()
	{
		
	}
	
	public void DemandInput()
	{
		
	}
		
}
