package coalAdminPages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import coalBase.BaseMethods;

public class Routing extends BaseMethods
{
	public void routingAddbtn()
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@onclick='LoadRoutingCreate();']")).click();
	}
	
	public void routeName(String data1)
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='Name']")).sendKeys(data1);
	}
	
	public void routeProduct(String data2)
	{
		Thread.sleep(2000);
		if(data2.equalsIgnoreCase("Product"))
		{
		driver.findElement(By.xpath("//input[@id='rbProduct']")).click();
		driver.findElement(By.xpath("//input[@id='txtModelRouteFinishedGood']")).sendKeys(data2);
		}
		else if(data2.equalsIgnoreCase("Product Family"))
		{
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@id='rbProductFamily']")).click();
			driver.findElement(By.xpath("//input[@name='AutoProductFamily']")).sendKeys("");
		}
	}
	
	public void routeStatus(String data1)
	{
		Thread.sleep(2000);
		if(data1.equalsIgnoreCase("Active"))
		{
		Select active = new Select(driver.findElement(By.xpath("//select[@id='Status']")));
		active.selectByVisibleText("Active");
		}
		else if(data1.equalsIgnoreCase("InActive"))
		{
			Select inactive = new Select(driver.findElement(By.xpath("//select[@id='Status']")));
			inactive.selectByVisibleText("InActive");
		}
		else if(data1.equalsIgnoreCase("InProgress"))
		{
			Select inprogress = new Select(driver.findElement(By.xpath("//select[@id='Status']")));
			inprogress.selectByVisibleText("InProgress");
		}
	}
	
	public void isTemplate(String data1)
	{
		Thread.sleep(2000);
		if(data1.equalsIgnoreCase("yes"))
		{
			driver.findElement(By.xpath("//input[@id='IsTemplate']")).click();
		}else if(data1.equalsIgnoreCase("No"))
		{
		}
	}
	
	public void needFocusFactory(String data1)
	{
		Thread.sleep(2000);
		if(data1.equalsIgnoreCase("yes"))
		{
			driver.findElement(By.xpath("//input[@id='IsFocusFactoryNeeded']")).click();
		}else if(data1.equalsIgnoreCase("No"))
		{	
		}
	}
	
	public void saveButton()
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='btnSave']")).click();
	}
	
	public void cancelbutton()
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='btnCancel']")).click();
	}
	
	public void expandAll()
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='btnExpandOrCollapseAll']")).click();
	}
	
}
