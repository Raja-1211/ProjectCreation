package coalAdminPages;

import org.openqa.selenium.By;

import adminTestCases.ManufacturingRelationshipTC;
import coalBase.BaseMethods;

public class ManufacturingRelationship extends BaseMethods
{

	public void manufacturingRelationshipadd()
	{
		driver.findElement(By.xpath("//*[@id='divBillOfMaterial']/div[1]/div/a")).click();
	}
	
	public void productcheckbox()
	{
		//Thread.sleep(2000);
		//if(data1.equalsIgnoreCase("Product"))
		//{
		driver.findElement(By.xpath("//input[@id='rdoProduct")).click();
		//}
		/*else if(data1.equalsIgnoreCase("Product Family"))
		{
		driver.findElement(By.xpath("//input[@id='rdoFamily']")).click();
		}*/
	}
	
	public void manufacturingRelationship(String data1)
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='autoList']")).sendKeys(data1);
	}
	
	public void MROperations(String data2)
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='autoOperation']")).sendKeys(data2);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='btnOpertation']")).click();
    }
	
	public void autoComponent(String data3)
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='autoComponent']")).sendKeys(data3);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='numQty']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='numQty']")).sendKeys("");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='btnComponents']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='btnSave']")).click();
	}

	public RoutingTC RoutingAdmin() throws InterruptedException
	{
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[contains(text(),'Routing')]")).click();
		return new RoutingTC();
	}
}
