package coalAdminPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import coalBase.BaseMethods;

public class CreateModel extends BaseMethods
{

	public CreateModel(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void CreateNewModelbutton() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='btnCreateNewModel']")).click();
	}
	
	public void CreateNewModelName(String data1) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='txtModelName']")).sendKeys(data1);	
	}
	
	public void CreateNewModelDescription(String data2) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//textarea[@id='taModelDescription']")).sendKeys(data2);
	}
	
	public void CreateNewModelUoM() throws InterruptedException
	{
		Thread.sleep(2000);
		Select uom = new Select(driver.findElement(By.xpath("//Select[@id='drpUnitOfMeasurement']")));
		Thread.sleep(2000);
		uom.selectByVisibleText("EACH");		
	}
	
	public void CreateNewModelDivision() throws InterruptedException
	{
		Thread.sleep(2000);
		Select division = new Select(driver.findElement(By.xpath("//Select[@id='drpDivision']")));
		Thread.sleep(2000);
		division.selectByVisibleText("3M IPC");
	}

	public void CreateNewModelPlanningMethod(String data3) throws InterruptedException
	{
		Thread.sleep(2000);
		if(data3.equalsIgnoreCase("Time-based"))
		{
		driver.findElement(By.xpath("//input[@id='PlanningMethod' and @value='False']")).click();
		}else
		{
			driver.findElement(By.xpath("//input[@id='PlanningMethod' and @value='True']")).click();
		}
	}
		
	public void CreateNewModelNeedFocusFactory(String data4) throws InterruptedException
	{
		Thread.sleep(2000);
		if(data4.equalsIgnoreCase("Yes"))
		{
		driver.findElement(By.xpath("//input[@id='IsFocusFactory' and @value='True']")).click();
		}else
		{
			driver.findElement(By.xpath("//input[@id='IsFocusFactory' and @value='False']")).click();
		}
	}
	
	public void CreateNewModelPeriodType(String data5) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//select[@id='ddlPeriodType']")).click();
		Thread.sleep(2000);
		
		if(data5.equalsIgnoreCase("Monthly"))
		{
			Select periodtype = new Select(driver.findElement(By.xpath("//Select[@id='ddlPeriodType']")));
			Thread.sleep(2000);
			periodtype.selectByVisibleText("Monthly");
			
		}else if(data5.equalsIgnoreCase("Quarterly"))
		{
			Select periodtype = new Select(driver.findElement(By.xpath("//Select[@id='ddlPeriodType']")));
			Thread.sleep(2000);
			periodtype.selectByVisibleText("Quarterly");
		}
		else if(data5.equalsIgnoreCase("Annually"))
		{
			Select periodtype = new Select(driver.findElement(By.xpath("//Select[@id='ddlPeriodType']")));
			Thread.sleep(2000);
			periodtype.selectByVisibleText("Annually");
		}
	}
	
	public void CreateNewModelPeriods(String data6) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='spinner1']")).clear();
		driver.findElement(By.xpath("//input[@id='spinner1']")).sendKeys(data6);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@id='btnCreateNewModelSaveInCreatePage']")).click();
	}	
}
