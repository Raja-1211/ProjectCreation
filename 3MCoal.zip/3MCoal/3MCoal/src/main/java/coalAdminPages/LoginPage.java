package coalAdminPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import adminTestCases.TC_01;
import coalBase.BaseMethods;

public class LoginPage extends BaseMethods
{
	/**
	 * This method will initialize the web elements which are defined in Page Objects
	 * @author Raja
	 */
		
	public LoginPage(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	/**
	 * This method will pass the Username in the Username text field
	 * @Param usernamedata - This locator will be passed to the Username textfield
	 * @author Raja
	 */
	
	@FindBy(how=How.XPATH, using="//input[@id='UserName']")
	public WebElement eleUserName;
	
	public LoginPage UserName(String usernamedata) 
	{		
	    eleUserName.sendKeys(usernamedata);
		return this;
	}
	
	/**
	 * This method will pass the Password in the Password text field
	 * @Param passworddata - This locator will be passed to the Password textfield
	 * @author Raja
	 */
	
	@FindBy(how=How.XPATH, using="//input[@id='Password']")
	public WebElement elePassword;
	
	public LoginPage Password(String passworddata) 
	{
		elePassword.sendKeys(passworddata);
		return this;
	}
	
	/**
	 * This method will click the Login Button link in the Login Page
	 * @author Raja
	 */
		
	@FindBy(how=How.XPATH, using="//*[@id='divLoginForm']/form/div[7]/button")
	public WebElement eleLogin;
	public LoginPage clickLogIn()
	{
		eleLogin.click();
		return this;
	}	
}

