package testingg;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import coalBase.BaseMethods;

public class Testing extends BaseMethods
{
	@Test(priority=1)
	public void testinggg() throws Exception
	{
		startApplication("Chrome");
		Thread.sleep(2000);
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//input[@id='UserName']")).sendKeys("A5G7QZZ");
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("Congruent2018!@#$");
		
		driver.findElement(By.xpath("//*[@id='divLoginForm']/form/div[7]/button")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//i[@class='fa fa-user fa-lg']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Product | Family | Group')]")).click();		
}
	@Test(priority=2)
	public void Productgroupadd() throws Exception
	{
		Thread.sleep(4000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
		Thread.sleep(5000);
	    //Add Button
        driver.findElement(By.xpath("//*[@id='productGroupGrid']/div[1]/a")).click();
        driver.findElement(By.xpath("//input[@id='Name']")).sendKeys("Sticky Coal");
        Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='productGroupGrid']/div[3]/table/tbody/tr[1]/td[6]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//li[contains(text(),'Rolls')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='productGroupGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
		
	}
	
	@Test(priority=3)
	public void ProductFamilyadd() throws Exception
	{
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[1]/a")).click();
		Thread.sleep(2000);
	 	driver.findElement(By.xpath("//input[@id='Name']")).sendKeys("Product Family");
	 	Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[3]/table/tbody/tr[1]/td[7]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//li[contains(text(),'Rolls')]")).click();
		Thread.sleep(2000);
		WebElement test = driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[3]/table/tbody/tr[1]/td[8]/span[1]/span/span[2]/span"));
		test.click();
		Thread.sleep(2000);
		test.sendKeys("Sticky Coal");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
	}
	
   	
	
			/*FileInputStream fis = new FileInputStream(new File("D:\\Selenium Workspace\\ReportTest\\ExcelData\\DataExcelImport.xlsx"));
			
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet ws = wb.getSheetAt(6);
			XSSFSheet ws1 = wb.getSheetAt(7);
			int RowCount = ws.getLastRowNum()+1;
			
			int ColumnCount = ws.getRow(0).getLastCellNum();
			
			label:
			for(int k=2; k<RowCount; k++)
			{
				int z=0;
			XSSFRow Row = ws.getRow(k);
			XSSFCell cell = Row.getCell(z);
			String cellValue = cell.toString();
			
			System.out.println(cellValue);
			
			    int RowCount1 = ws1.getLastRowNum()+1;
			    System.out.println("Second Sheet Row Count"+RowCount1);
			    for(int j=2;j<RowCount1;j++)
			    {
			    	int zz=2;
			      XSSFRow Row1 = ws1.getRow(j);
			      XSSFCell cell1 = Row1.getCell(zz);
			      String cellValue1 = cell1.toString();
			
			      System.out.println(cellValue1);
			      
			      	if(cellValue.equals(cellValue1))
			      		{
			      			// Open the dropdown so the options are visible
			       		//WebElement test = driver.findElement(By.xpath("//*[@id='ProductGroupID_listbox']"));
			      			      		
			      			// Get all of the options
			      			List<WebElement> options = test.findElements(By.tagName("li"));
			      			 Loop through the options and select the one that matches
			      			for (WebElement opt : options) 
			      			{
			      				if (opt.getText().equals(cellValue)) 
			      				{
			      					opt.click();
			      					break label;
			      				}
			      				
			      			}
			      		}
			      	zz++;
			     
			     }
			    z++;
	          }
	}


		}



	
*/	
}
