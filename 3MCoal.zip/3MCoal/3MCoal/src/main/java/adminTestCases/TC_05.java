package adminTestCases;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import coalAdminPages.ManufacturingRelationship;
import coalBase.BaseMethods;
import utilis.DPMR;
import utilis.DPMRCO;
import utilis.Reports;

public class TC_05 extends Reports
{
	@DataProvider(name="ManufacturingRelationship")
	public static Object[][] readMR() throws Exception 
	{
		Object[][] arrayObject = DPMR.readOperationMR();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ManufacturingRelationship")
	public void TC_01readMRTC(String data1,String data2,String data3) throws Exception
	{
	Thread.sleep(2000);
	test = extent.createTest("Manufacturing Test");
	ManufacturingRelationship manufrel = new ManufacturingRelationship(driver);
	manufrel.manufacturingRelationshipadd();
	//manufrel.productcheckbox();
	manufrel.manufacturingRelationship(data1);
	manufrel.MROperations(data2);
	manufrel.autoComponent(data3);
	}
	
	@DataProvider(name="ManufacturingRelationshipCO")
	public static Object[][] readMRCO() throws Exception 
	{
		Object[][] arrayObject = DPMRCO.readOperationMRCO();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ManufacturingRelationshipCO")
	public void TC_02readMRTCCO(String data1,String data2,String data3) throws Exception
	{
	Thread.sleep(2000);
	test = extent.createTest("Manufacturing Componet/Operation Test");
	ManufacturingRelationship manufrel = new ManufacturingRelationship(driver);
	manufrel.manufacturingRelationshipadd();
	//manufrel.productcheckbox();
	manufrel.manufacturingRelationship(data1);
	manufrel.MROperations(data2);
	manufrel.autoComponent(data3);
	}
}
