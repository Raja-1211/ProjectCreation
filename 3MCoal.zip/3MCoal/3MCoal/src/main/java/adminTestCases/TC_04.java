package adminTestCases;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import coalAdminPages.OperationWorkCenter;
import coalBase.BaseMethods;
import utilis.DPOperation;
import utilis.DPOperationGroup;
import utilis.DPOperationType;
import utilis.DPUnitConverison;
import utilis.DPWorkCenter;
import utilis.Reports;

public class TC_04 extends Reports
{
	@DataProvider(name="ReadOperation")
	public static Object[][] readOperation() throws Exception 
	{
		Object[][] arrayObject = DPOperation.readOperation();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ReadOperation")
	public void TC_03readOperationtc(String data1,String data2,String data3,String data4,String data5,String data6) throws Exception
	{
	test = extent.createTest("Operation Test");
	Thread.sleep(2000);
	OperationWorkCenter operationtest = new OperationWorkCenter(driver);
	operationtest.operationName(data1);
	operationtest.operationSName(data2);
	operationtest.operationRegion(data3);
	operationtest.operationGroupName(data4);
	operationtest.operationTypeName(data5);
	operationtest.operationDivisionName(data6);
	}
	
	@DataProvider(name="ReadOperationGroup")
	public static Object[][] readOperationGroup() throws Exception 
	{
		Object[][] arrayObject = DPOperationGroup.readOperationGroup();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ReadOperationGroup")
	public void TC_02readOperationGrouptc(String data7) throws Exception
	{
		test = extent.createTest("Operation Group Test");
		OperationWorkCenter opg = new OperationWorkCenter(driver);
		opg.operationGroup(data7);
	}
	
	@DataProvider(name="ReadOperationType")
	public static Object[][] readOperationType() throws Exception 
	{
		Object[][] arrayObject = DPOperationType.readOperationType();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ReadOperationType")
	public void TC_01readOperationTypetc(String data8) throws Exception
	{
		test = extent.createTest("Operation Type Test");
		OperationWorkCenter optype = new OperationWorkCenter(driver);
		optype.operationType(data8);
	}
	
	@DataProvider(name="ReadOperationWC")
	public static Object[][] readOperationWc() throws Exception 
	{
		Object[][] arrayObject = DPWorkCenter.readOperationWC();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ReadOperationWC")
	public void TC_04readOperationWctc(String data9,String data10) throws Exception
	{
		test = extent.createTest("Operation Work Center Test");
		OperationWorkCenter opwc = new OperationWorkCenter(driver);
		opwc.workCenterName(data9);
		opwc.workCenterSName(data10);
	}
	
	@DataProvider(name="ReadOperationUnitConc")
	public static Object[][] readOperationUnitConversion() throws Exception 
	{
		Object[][] arrayObject = DPUnitConverison.readOperationuc();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ReadOperationUnitConc")
	public void TC_05readOperationUnitConv(String data11,String data12,String data13,String data14, String data15) throws Exception
	{
		test = extent.createTest("Operation UnitConversion Test");
		OperationWorkCenter opuc = new OperationWorkCenter(driver);
		opuc.unitConversionlevel(data11);
		opuc.unitConversionWC(data12);
		opuc.unitConversionFunit(data13);
		opuc.unitConversionTunit(data14);
		opuc.unitConversionCFactor(data15);		
	}
	
}
