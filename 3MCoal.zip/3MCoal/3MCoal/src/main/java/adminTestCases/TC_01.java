package adminTestCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import coalAdminPages.AdminPage;
import coalAdminPages.LoginPage;
import coalBase.BaseMethods;
import utilis.DataProviderLogin;
import utilis.Reports;

/**
 * This class contains the Test Cases for the "Coal-Login Page"
 * @author Raja
 */

public class TC_01 extends Reports
{
	/**
	 * This method will launch the Chrome or IE browser
	 * This method will load the specified browser
	 * @author Raja
	 */
	
	@BeforeClass
	public void startapp()
	{
		startApplication("Chrome");
	}

	/**
	 * This method will fetch the Login data from the Excel and pass it to the Login Page method
	 * @author Raja
	 */
	
	@DataProvider(name="Login")
	public static Object[][] loginData() throws Exception 
	{
		Object[][] arrayObject = DataProviderLogin.readInput();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Login data to the Username and Password methods 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Login")
	public void TC_01LoginPage(String usernamedata, String passworddata) throws Exception
	{
		test = extent.createTest("Login Page Test");
		LoginPage coallogin = new LoginPage(driver);		
		coallogin.UserName(usernamedata);
		coallogin.Password(passworddata);
		coallogin.clickLogIn();
		AdminPage adminpage = new AdminPage(driver);
		adminpage.adminmainpage();
		adminpage.adminBaseMaster();
		Thread.sleep(50000);
	}	
}	
	
